package com.example.nft.nft_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NftBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
