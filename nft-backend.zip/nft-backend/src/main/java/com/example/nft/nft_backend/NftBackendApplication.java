package com.example.nft.nft_backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NftBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(NftBackendApplication.class, args);
	}

}
